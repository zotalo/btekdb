<?php 
session_start();
if(isset($_SESSION['username'])) {
	$PageTitle="Bowtech Ημερολόγιο";
	include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php');
	echo "<p id='welcome'> Καλώς ήρθες: <i>".$_SESSION['username']."</i><a id='logout' href=' logout_parse.php'> Αποσύνδεση</a>";
	}
	else {
		header( 'refresh: 1; /index.php' );
		die ("You are not logged in");
	}

?>
	<div class="content">
	<?php
echo '<div class="cur-date">';
echo date('d-m-Y H:i'); 
echo '</div>';
?>
	<?php include 'insert_calendar.php'; ?>
	<section id="insert_form">
		<?php include 'insert_calendar_form.php'; ?>
	</section>
	<div class="calendar-all">
	<h2 class="h2plain"><a href='calendar_table_all.php'>Όλες οι καταχωρήσεις</a></h2>
	</div>
	<div class="calendar_table">
	<h2 class="h2imer">Ημερολόγιο - Ραντεβού</h2>
	<?php include 'calendar_table.php'; ?>
	</div>
	
	</div>
	
</section>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php');
?>