﻿
<ul id="main-menu">
				<li><a href="/includes/pelatologio.php">Πελατολογιο</a></li>
				<li><a href="/includes/calendar.php">Ραντεβου</a></li>
				<li><a href="/includes/diadikasies.php">Διαδικασιες</a></li>
				<li><a href="/includes/bowtech.php">Αρθρα</a></li>
</ul>