		<?php echo "<form id='insert_entry_form' action='/includes/insert_customers.php' method='post'>
			<div class='form_format'><span class='in_name'>Επίθετο: </span><input type='text' placeholder='' name='Epitheto'/></div><br>
			<div class='form_format'><span class='in_name'>Όνομα: </span><input type='text' placeholder='' name='Onoma'/></div><br>
			<div class='form_format'><span class='in_name'>Διεύθυνση: </span><input type='text' placeholder='' name='Dieuthinsi'/></div><br>
			<div class='form_format'><span class='in_name'>Σταθερό: </span><input type='tel' placeholder='' name='Tilefono_Stath'/></div><br>
			<div class='form_format'><span class='in_name'>Κινητό: </span><input type='tel' placeholder='' name='Tilefono_Kin'/></div><br>
			<div class='form_format'><span class='in_name'>Email: </span><input type='email' placeholder='' name='Email'></div><br>
			<div class='form_format'><span class='in_name'>Σημειώσεις: </span><input type='text' placeholder='' name='Simiosis'/></div><br>
			<div class='form_format'><span class='in_name'>Ποσό: </span><input type='text' placeholder='' name='Poso'/></div><br>
			<div class='form_format'><span class='in_name'>Ηλικία: </span><input type='number' placeholder='' name='Ilikia'  /></div><br>
			<div class='form_format'><span class='in_name'>Εργασία: </span><input type='text' placeholder='' name='Ergasia'  /></div><br>
			<div class='form_format'><span class='in_name'>Δραστηριότητες: </span><input type='text' placeholder='' name='Drastiriotites'  /></div><br>
			<div class='form_format'><span class='in_name'>Παρούσα Κατάσταση: </span><input type='text' placeholder='' name='Parousa_Katastasi'  /></div><br>
			<div class='form_format'><span class='in_name'>Rate: </span><input type='number' placeholder='' min='1' max='10' value='1' name='Rate' oninput='this.form.amountInput.value=this.value' /></div><br>
			<div class='form_format'><span class='in_name'>Προηγούμενες Θεραπείες: </span><input type='text' placeholder='' name='Proigoumenes_Therapies'  /></div><br>
			<div class='form_format'><span class='in_name'>Φαρμακευτική Αγωγή: </span><input type='text' placeholder='' name='Farmakeutiki_Agogi'  /></div><br>
			<div class='submit_button'><input type='submit' name='submit'/></div>
		</form>" ; ?>