<?php
echo "<a href='includes/insert_entry.php'><button class='moduleb'>Εισαγωγή Πελάτη</button></a>
<button class='moduleb'>Εισαγωγή Ραντεβού</button>
<button class='moduleb'>Εισαγωγή Άρθρου</button>";
?>