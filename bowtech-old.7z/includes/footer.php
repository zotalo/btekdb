<footer>
    <span>Bowtech DataBase &copy; 2015 - 
	<script>
						var theDate=new Date()
						document.write(theDate.getFullYear())
					</script>  All rights reserved</span>

</footer>
</body>
</html>