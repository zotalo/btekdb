<?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/datalogin.php';?>
		<div id="head-title">
			<h1><a href="/index.php">Βαση Δεδομενων Πελατων Bowtech</a></h1>
		</div>
<?php 
if(isset($_SESSION['username'])){
	echo "<nav>";
	include $_SERVER['DOCUMENT_ROOT'] . '/includes/navigation.php';
echo "</nav>"; 
}
?>